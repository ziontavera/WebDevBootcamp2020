Recreate the image in HTML

![](https://i.gyazo.com/5a50b335e2fcc5e2a3f05f554edfda82.png)
