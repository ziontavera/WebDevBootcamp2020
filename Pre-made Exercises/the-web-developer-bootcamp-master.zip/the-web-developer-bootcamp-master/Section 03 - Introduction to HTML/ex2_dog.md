Recreate the webpage

![](https://i.gyazo.com/ab0c7c023751c986e6b06c547ee4737b.png)
