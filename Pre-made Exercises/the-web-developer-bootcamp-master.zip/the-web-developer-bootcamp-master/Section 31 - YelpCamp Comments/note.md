See the all YelpCamp code in the section 26
