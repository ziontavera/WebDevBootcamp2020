$("button").on("click", function(){
	// // Fade OUT on click
	// $('div').fadeOut(1000, function(){
	// 	$(this).remove();
	// });
	// // Fade IN on click
	// $('div').fadeIn(1000);
	// // Toggle display via fade
	$("div").fadeToggle(500);
});

// $("button").on("click", function(){
// 	$("div").slideToggle(500);
// });