var tag = document.getElementById("highlight");

var tags = document.getElementsByClassName("bolded");

var tagname = document.getElementsByTagName("li");

//only gives the first instance when there's multiple of the query
var fromQuery = document.querySelector("#highlight");

var fromQuery2 = document.querySelectorAll("h1");