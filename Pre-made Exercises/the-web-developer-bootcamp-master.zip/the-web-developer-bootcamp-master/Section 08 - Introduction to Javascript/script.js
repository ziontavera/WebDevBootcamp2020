var firstName = prompt("What is your first name?");
var lastName = prompt("... and your last name?");
var age = prompt("How old are you " + firstName + "?");
console.log("Your full name is " + firstName + " " + lastName + ".");
console.log("You have encircled the sun " + age + " times.");