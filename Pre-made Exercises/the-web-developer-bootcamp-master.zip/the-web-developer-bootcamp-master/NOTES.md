# Useful websites:

* https://csszengarden.com

* https://colours.neilorangepeel.com

* https://colourpicker.com

* https://specificity.keegan.st - specificity calculator

* https://cssfontstack.com

* https://unsplash.com - free pictures

* https://fortawesome.github.io - icons and fonts

* https://uigradients.com - nice gradients

* https://www.programmableweb.com/ - a lot of APIs 

# Useful tools

* https://www.npmjs.com/package/faker - TONS of fake data
