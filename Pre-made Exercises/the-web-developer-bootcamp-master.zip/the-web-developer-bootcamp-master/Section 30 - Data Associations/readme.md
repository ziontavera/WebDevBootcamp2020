#Associations

##Intro to Associations
* Define associations
* Discuss one:one, one:many, and many:many relationships

##Embedding Data
User
Post

##Referencing Data

##Module.Exports
* Introduce module.exports
* Move our models into seperate files