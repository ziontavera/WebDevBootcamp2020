Recreate the page in HTML

![](https://i.imgur.com/9e20g9v.png)
